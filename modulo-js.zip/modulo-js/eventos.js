//document.body.innerHTML = '<h1>Olá mundo</h1> <hr>';

function cadastro() {
    document.getElementById('conteudo').innerHTML = '...Cadastro...';
}

function listar() {
    document.getElementById('conteudo').innerHTML = '...Listando...';
}

function relatorio() {
    document.getElementById('conteudo').innerHTML = '...Relatorio...';
}